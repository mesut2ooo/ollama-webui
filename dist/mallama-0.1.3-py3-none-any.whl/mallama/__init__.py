"""Ollama Web UI - A beautiful web interface for Ollama"""
__version__ = "0.1.3"